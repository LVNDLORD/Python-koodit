create procedure ps_setup_reset_to_default(IN in_verbose tinyint(3))
    comment '
             Description
             Resets the Performance Schema setup to the default settings.
             Parameters
             in_verbose (BOOLEAN):
               Whether to print each setup stage (including the SQL) whilst running.
             Example
             mysql> CALL sys.ps_setup_reset_to_default(true)\G
             *************************** 1. row ***************************
             status: Resetting: setup_actors
             DELETE
             FROM performance_schema.setup_actors
              WHERE NOT (HOST = ''%'' AND USER = ''%'' AND ROLE = ''%'')
             1 row in set (0.00 sec)
             *************************** 1. row ***************************
             status: Resetting: setup_actors
             INSERT IGNORE INTO performance_schema.setup_actors
             VALUES (''%'', ''%'', ''%'')
             1 row in set (0.00 sec)
             ...
             mysql> CALL sys.ps_setup_reset_to_default(false)\G
             Query OK, 0 rows affected (0.00 sec)
            '
BEGIN
    SET @query = 'DELETE\n                    FROM performance_schema.setup_actors\n                   WHERE NOT (HOST = ''%'' AND USER = ''%'' AND ROLE = ''%'')';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_actors\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'INSERT IGNORE INTO performance_schema.setup_actors\n                  VALUES (''%'', ''%'', ''%'', ''YES'', ''YES'')';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_actors\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'UPDATE performance_schema.setup_instruments\n                     SET ENABLED = sys.ps_is_instrument_default_enabled(NAME),\n                         TIMED   = sys.ps_is_instrument_default_timed(NAME)';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_instruments\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'UPDATE performance_schema.setup_consumers\n                     SET ENABLED = IF(NAME IN (''events_statements_current'', ''events_transactions_current'', ''global_instrumentation'', ''thread_instrumentation'', ''statements_digest''), ''YES'', ''NO'')';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_consumers\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'DELETE\n                    FROM performance_schema.setup_objects\n                   WHERE NOT (OBJECT_TYPE IN (''EVENT'', ''FUNCTION'', ''PROCEDURE'', ''TABLE'', ''TRIGGER'') AND OBJECT_NAME = ''%''\n                     AND (OBJECT_SCHEMA = ''mysql''              AND ENABLED = ''NO''  AND TIMED = ''NO'' )\n                      OR (OBJECT_SCHEMA = ''performance_schema'' AND ENABLED = ''NO''  AND TIMED = ''NO'' )\n                      OR (OBJECT_SCHEMA = ''information_schema'' AND ENABLED = ''NO''  AND TIMED = ''NO'' )\n                      OR (OBJECT_SCHEMA = ''%''                  AND ENABLED = ''YES'' AND TIMED = ''YES''))';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_objects\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'INSERT IGNORE INTO performance_schema.setup_objects\n                  VALUES (''EVENT''    , ''mysql''             , ''%'', ''NO'' , ''NO'' ),\n                         (''EVENT''    , ''performance_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''EVENT''    , ''information_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''EVENT''    , ''%''                 , ''%'', ''YES'', ''YES''),\n                         (''FUNCTION'' , ''mysql''             , ''%'', ''NO'' , ''NO'' ),\n                         (''FUNCTION'' , ''performance_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''FUNCTION'' , ''information_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''FUNCTION'' , ''%''                 , ''%'', ''YES'', ''YES''),\n                         (''PROCEDURE'', ''mysql''             , ''%'', ''NO'' , ''NO'' ),\n                         (''PROCEDURE'', ''performance_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''PROCEDURE'', ''information_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''PROCEDURE'', ''%''                 , ''%'', ''YES'', ''YES''),\n                         (''TABLE''    , ''mysql''             , ''%'', ''NO'' , ''NO'' ),\n                         (''TABLE''    , ''performance_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''TABLE''    , ''information_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''TABLE''    , ''%''                 , ''%'', ''YES'', ''YES''),\n                         (''TRIGGER''  , ''mysql''             , ''%'', ''NO'' , ''NO'' ),\n                         (''TRIGGER''  , ''performance_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''TRIGGER''  , ''information_schema'', ''%'', ''NO'' , ''NO'' ),\n                         (''TRIGGER''  , ''%''                 , ''%'', ''YES'', ''YES'')';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: setup_objects\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
    SET @query = 'UPDATE performance_schema.threads\n                     SET INSTRUMENTED = ''YES''';
    IF (in_verbose) THEN
        SELECT CONCAT('Resetting: threads\n', REPLACE(@query, '  ', '')) AS status;
    END IF;
    PREPARE reset_stmt FROM @query;
    EXECUTE reset_stmt;
    DEALLOCATE PREPARE reset_stmt;
END;

